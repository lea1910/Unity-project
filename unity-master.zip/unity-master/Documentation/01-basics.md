# Unity - ETPA Game 1 2024 - Chapter 1: Basics

**Objective**: Control a character to activate a lever and open a door.

![Final render of this chapter](./Images/chapters-01_basics-final.gif)

WIP :)

---

[<= Back to summary](README.md) | [=> Next chapter](./02-guess-the-number.md)