# Unity - ETPA Game 1 2024 - Chapter 3: Dialogues

**Objective**: A mini-game that requires to spawn prefabs at runtime, and configured using [`ScriptableObject`](https://docs.unity3d.com/Manual/class-ScriptableObject.html) assets.

![Final render of this chapter](./Images/chapters-04_cannon-survivor-final.gif)

WIP :)

---

[<= Back to summary](README.md)