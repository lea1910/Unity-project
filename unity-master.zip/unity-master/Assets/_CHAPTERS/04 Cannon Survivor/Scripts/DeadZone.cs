using UnityEngine;

public class DeadZone : MonoBehaviour
{
    
    /**
     *  @todo
     *  - Destroy any object that exits the Dead Zone trigger
     */

}
